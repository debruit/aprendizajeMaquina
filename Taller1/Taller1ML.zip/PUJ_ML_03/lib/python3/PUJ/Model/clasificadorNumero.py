
import numpy as np
from .Logistic import *

class clasificadorNumero():

  def __init__(self):
    self.modelos=[]
    self.size=784


  def agregarModelos(self, npzfile):
    for i in npzfile.files:
      m = Logistic()
      m.setParameters(npzfile[i])
      self.modelos.append(m)

  def evaluar(self,x):
    evaluados=[]
    for i in range(len(self.modelos)):
      evaluados.append(self.modelos[i].evaluate(x))
    arr = np.array(evaluados)
    arr= arr[:,:,0].T
    return np.argmax(arr,axis=1)

  def evaluarImagen(self, img):
    y = []
    for model in self.modelos:
      y += [model.evaluate(img)[0, 0]]
    return np.argmax(np.array(y))
