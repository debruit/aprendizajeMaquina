// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================

#include <iostream>
#include <PUJ_ML/Export.h>
#include <PUJ_ML/Optimizer/Base.h>

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Optimizer::Base< _TScalar >::
Base( TCost* cost )
  : m_Cost( cost )
{
  this->m_Debug =
    [=]( TCost* c, TNatural i, TScalar J, TScalar dJ, bool s ) -> bool
    {
      if( s )
        std::cout
          << "Iteration: " << i << " ;\t" 
          << "cost: " << J << " ;\t" 
          << "difference: " << dJ
          << std::endl;
      return( false );
    };
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Optimizer::Base< _TScalar >::
TNatural PUJ_ML::Optimizer::Base< _TScalar >::
maximumNumberOfIterations( ) const
{
  return( this->m_MaximumNumberOfIterations );
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Optimizer::Base< _TScalar >::
TNatural PUJ_ML::Optimizer::Base< _TScalar >::
numberOfDebugIterations( ) const
{
  return( this->m_NumberOfDebugIterations );
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Optimizer::Base< _TScalar >::
TNatural PUJ_ML::Optimizer::Base< _TScalar >::
iteration( ) const
{
  return( this->m_Iteration );
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Optimizer::Base< _TScalar >::
setMaximumNumberOfIterations( const TNatural& i )
{
  this->m_MaximumNumberOfIterations = i;
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Optimizer::Base< _TScalar >::
setNumberOfDebugIterations( const TNatural& i )
{
  this->m_NumberOfDebugIterations = i;
}

// -------------------------------------------------------------------------
template class PUJ_ML_EXPORT PUJ_ML::Optimizer::Base< float >;
template class PUJ_ML_EXPORT PUJ_ML::Optimizer::Base< double >;
template class PUJ_ML_EXPORT PUJ_ML::Optimizer::Base< long double >;

// eof - $RCSfile$
