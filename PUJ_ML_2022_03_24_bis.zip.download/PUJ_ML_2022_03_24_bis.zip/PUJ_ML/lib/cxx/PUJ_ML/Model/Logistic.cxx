// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================

#include <PUJ_ML/Export.h>

#include <cmath>
#include <PUJ_ML/Model/Logistic.h>

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Model::Logistic< _TScalar >::Cost::
Cost( Self* model, const TMatrix& X, const TMatrix& Y )
  : Superclass::Cost( model, X, Y )
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Model::Logistic< _TScalar >::
TScalar PUJ_ML::Model::Logistic< _TScalar >::Cost::
evaluate( TRow* g )
{
  static const TScalar _1 = TScalar( 1 );
  static const TScalar e = std::numeric_limits< TScalar >::epsilon( );
  TNatural n = this->m_Model->inputSize( );

  // Separate zeros and ones
  struct ZeroOneVisitor
  {
    void init( const TScalar& v, Eigen::Index i, Eigen::Index j )
      {
        if( v == TScalar( 0 ) ) this->zeros.push_back( i );
        else                    this->ones.push_back( i );
      }
    void operator()( const TScalar& v, Eigen::Index i, Eigen::Index j )
      {
        if( v == TScalar( 0 ) ) this->zeros.push_back( i );
        else                    this->ones.push_back( i );
      }
    std::vector< Eigen::Index > zeros;
    std::vector< Eigen::Index > ones;
  };
  ZeroOneVisitor zo;
  this->m_Y->visit( zo );

  // Evaluate model at current parameters
  TMatrix Z = this->m_Model->evaluate( *this->m_X );

  // Compute cost
  TScalar J = TScalar( 0 );
  J -= ( Z( zo.ones, Eigen::placeholders::all ).array( ) + e ).log( ).sum( );
  J -= ( ( _1 - Z( zo.zeros, Eigen::placeholders::all ).array( ) ) + e ).log( ).sum( );
  J /= TScalar( this->m_X->rows( ) );

  // Compute gradient
  if( g != nullptr )
  {
    if( g->cols( ) != n + 1 )
      *g = TRow::Zero( n + 1 );
    g->operator()( 0 ) = Z.mean( ) - this->m_mY;
    g->block( 0, 1, 1, n ) = 
      ( this->m_X->array( ).colwise( ) * Z.col( 0 ).array( ) ).
      colwise( ).mean( );
    g->block( 0, 1, 1, n ) -= this->m_mXY;
  } // end if

  return( J );
}

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Model::Logistic< _TScalar >::
Logistic( )
  : Superclass( )
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Model::Logistic< _TScalar >::
Logistic( const Self& other )
  : Superclass( *( dynamic_cast< const Superclass* >( &other ) ) )
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Model::Logistic< _TScalar >::
Self& PUJ_ML::Model::Logistic< _TScalar >::
operator=( const Self& other )
{
  return( *this );
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Model::Logistic< _TScalar >::
_evaluate( TMatrix& y, const TMatrix& x ) const
{
  /* TODO
     static const TScalar _0 = TScalar( 0 );
     static const TScalar _1 = TScalar( 1 );
     static const TScalar _b = TScalar( 40 );
     static const auto f = [=]( TScalar z ) -> TScalar
     {
     if     ( z >  _b ) return( _1 );
     else if( z < -_b ) return( _0 );
     else               return( _1 / ( _1 + std::exp( -z ) ) );
     };
     return( this->Superclass::evaluate( x ).unaryExpr( f ) );
  */
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Model::Logistic< _TScalar >::
_threshold( TMatrix& y, const TMatrix& x ) const
{
  /* TODO
     return(
     ( this->evaluate( x ).array( ) >= TScalar( 0.5 ) ).
     template cast< TScalar >( )
     );
  */
}

// -------------------------------------------------------------------------
template class PUJ_ML_EXPORT PUJ_ML::Model::Logistic< float >;
template class PUJ_ML_EXPORT PUJ_ML::Model::Logistic< double >;
template class PUJ_ML_EXPORT PUJ_ML::Model::Logistic< long double >;

// eof - $RCSfile$
