// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================

#include <PUJ_ML/Export.h>
#include <PUJ_ML/Optimizer/ADAM.h>

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Optimizer::ADAM< _TScalar >::
ADAM( TCost* cost )
  : Superclass( cost )
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Optimizer::ADAM< _TScalar >::
TScalar PUJ_ML::Optimizer::ADAM< _TScalar >::
firstDamping( ) const
{
  return( this->m_Beta1 );
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Optimizer::ADAM< _TScalar >::
TScalar PUJ_ML::Optimizer::ADAM< _TScalar >::
secondDamping( ) const
{
  return( this->m_Beta2 );
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Optimizer::ADAM< _TScalar >::
setFirstDamping( const TScalar& b )
{
  this->m_Beta1 = b;
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Optimizer::ADAM< _TScalar >::
setSecondDamping( const TScalar& b )
{
  this->m_Beta2 = b;
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Optimizer::ADAM< _TScalar >::
Fit( )
{
  // Initial values
  TNatural N = this->m_Cost->model( )->numberOfParameters( );
  TRow m = TRow::Zero( N ), v = TRow::Zero( N ), g;
  TScalar a = this->m_Alpha * TScalar( -1 );
  TScalar b1 = this->m_Beta1;
  TScalar b1t = this->m_Beta1;
  TScalar cb1 = TScalar( 1 ) - this->m_Beta1;
  TScalar b2 = this->m_Beta2;
  TScalar b2t = this->m_Beta2;
  TScalar cb2 = TScalar( 1 ) - this->m_Beta2;
  TScalar J0 = this->m_Cost->evaluate( &g ), J1;

  // Prepare loop
  bool stop = false;
  this->m_Iteration = 0;

  // Main loop
  while( !stop )
  {
    // Update moments estimate
    this->m_Iteration++;
    m = ( b1 * m ) + ( cb1 * g );
    v = ( b2 * v ) + TRow( cb2 * g.array( ).pow( 2 ) );

    // Compute bias-corrected moments estimate and update parameters
    this->m_Cost->move(
      ( ( m.array( ) / ( TScalar( 1 ) - b1t ) ) /
        (
          ( v.array( ) / ( TScalar( 1 ) - b2t ) ).sqrt( ) +
          this->m_Epsilon
          )
        ) * a
      );

    // Update gradient
    J1 = this->m_Cost->evaluate( &g );
    stop = this->m_Debug(
      this->m_Cost, this->m_Iteration, J0, J0 - J1,
      this->m_Iteration % this->m_NumberOfDebugIterations == 0
      );
    stop |= this->m_Iteration >= this->m_MaximumNumberOfIterations;
    stop |= ( ( J0 - J1 ) < this->m_Epsilon );
    J0 = J1;

    // Update dampings
    b1t *= b1;
    b2t *= b2;
  } // end while

  // Final debug call
  this->m_Debug( this->m_Cost, this->m_Iteration, J0, J0 - J1, true );
}

// -------------------------------------------------------------------------
template class PUJ_ML_EXPORT PUJ_ML::Optimizer::ADAM< float >;
template class PUJ_ML_EXPORT PUJ_ML::Optimizer::ADAM< double >;
template class PUJ_ML_EXPORT PUJ_ML::Optimizer::ADAM< long double >;

// eof - $RCSfile$
