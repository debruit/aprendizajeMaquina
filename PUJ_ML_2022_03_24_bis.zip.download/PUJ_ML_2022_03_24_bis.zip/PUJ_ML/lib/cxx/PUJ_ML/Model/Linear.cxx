// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================

#include <PUJ_ML/Export.h>
#include <PUJ_ML/Model/Linear.h>

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Model::Linear< _TScalar >::Cost::
Cost( Self* model, const TMatrix& X, const TMatrix& Y )
  : Superclass::Cost( model, X, Y )
{
  this->m_XtX = ( X.transpose( ) * X ) / TScalar( X.rows( ) );
  this->m_mX = X.colwise( ).mean( );
  this->m_mXY =
    ( X.array( ).colwise( ) * Y.col( 0 ).array( ) ).colwise( ).mean( );
  this->m_mY = Y.mean( );
  this->m_YtY = ( ( Y.transpose( ) * Y ) / TScalar( Y.rows( ) ) ).sum( );
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Model::Linear< _TScalar >::
TScalar PUJ_ML::Model::Linear< _TScalar >::Cost::
evaluate( TRow* g )
{
  static const TScalar _2 = TScalar( 2 );
  TNatural n = this->m_Model->inputSize( );
  Eigen::Map< TColumn > wc( this->m_Model->parameters( ) + 1, n );
  Eigen::Map< TRow > wr( this->m_Model->parameters( ) + 1, n );
  TScalar b = this->m_Model->parameters( )[ 0 ];

  TScalar J = b * b;
  J += wr * this->m_XtX * wc;
  J += ( _2 * b ) * ( this->m_mX * wc )( 0, 0 );
  J -= _2 * ( this->m_mXY * wc )( 0, 0 );
  J -= ( _2 * b ) * this->m_mY;
  J += this->m_YtY;

  if( g != nullptr )
  {
    if( g->cols( ) != n + 1 )
      *g = TRow::Zero( n + 1 );
    g->operator()( 0 ) =
      _2 * ( ( wr * this->m_mX )( 0, 0 ) + b - this->m_mY );
    g->block( 0, 1, 1, n ) =
      _2 * ( ( wr * this->m_XtX ) + ( this->m_mX * b ) - this->m_mXY );
  } // end if
  return( J );
}

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Model::Linear< _TScalar >::
Linear( )
  : Superclass( )
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Model::Linear< _TScalar >::
Linear( const Self& other )
  : Superclass( *( dynamic_cast< const Superclass* >( &other ) ) )
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Model::Linear< _TScalar >::
Self& PUJ_ML::Model::Linear< _TScalar >::
operator=( const Self& other )
{
  return( *this );
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Model::Linear< _TScalar >::
TNatural PUJ_ML::Model::Linear< _TScalar >::
outputSize( ) const
{
  return( 1 );
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Model::Linear< _TScalar >::
_evaluate( TMatrix& y, const TMatrix& x ) const
{
  // return( ( x * *this->m_P ).array( ) + this->m_B[ 0 ] );
}

// -------------------------------------------------------------------------
template class PUJ_ML_EXPORT PUJ_ML::Model::Linear< float >;
template class PUJ_ML_EXPORT PUJ_ML::Model::Linear< double >;
template class PUJ_ML_EXPORT PUJ_ML::Model::Linear< long double >;

// eof - $RCSfile$
