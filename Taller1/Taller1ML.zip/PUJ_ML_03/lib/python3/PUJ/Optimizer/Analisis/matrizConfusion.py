
import numpy as np

class matrizConfusion():

    def __init__(self ,tam, K=None):
        if K is None:
            self.K = np.zeros( ( tam, tam ))
            self.tamano = tam
        else:
            self.K = K
            self.tamano = K.shape[0]

    def setK(self ,tabla):
        self.K = tabla
        self.tamano = self.K.shape[0]

    def calcular(self ,y_real, y_est):
        for i in range( y_real.shape[ 0 ] ):
            self.K[ int( y_real[ i, 0 ] ), int( y_est[ i, 0 ] ) ] += 1
        # end for
        return self.K

    def exactitud(self):
        total =self.K.sum()
        sum =0
        for i in range (self.tamano):
            sum += self.K[i][i]
        return sum /total

    def recallCol(self ,col):
        num =self.K[col][col]
        den =self.K[: ,col].sum()
        return num /den

    def precisionRow(self ,row):
        num =self.K[row][row]
        den =self.K[row][:].sum()
        return num /den

    def presicionProm(self):
        precision =[]
        for i in range (self.tamano):
            precision.append(self.precisionRow(i))
        return np.array(precision).mean()

    def recallProm(self):
        recall =[]
        for i in range (self.tamano):
            recall.append(self.recallCol(i))
        return np.array(recall).mean()


    def f1_score(self):
        f1 = []
        for i in range(self.tamano):
            rc = self.recallCol(i)
            pc = self.precisionRow(i)
            f1.append(( 2 *rc *pc ) /(rc +pc))
        return np.array(f1).mean()