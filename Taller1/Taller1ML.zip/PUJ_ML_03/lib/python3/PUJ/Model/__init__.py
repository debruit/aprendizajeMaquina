## =========================================================================
## @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
## =========================================================================

from .Base import *
from .Linear import *
from .Logistic import *

## eof - $RCSfile$
