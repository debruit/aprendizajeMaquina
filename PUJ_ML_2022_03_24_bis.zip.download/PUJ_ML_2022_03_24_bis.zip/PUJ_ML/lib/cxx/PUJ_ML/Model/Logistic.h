// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================
#ifndef __PUJ_ML__Model__Logistic__h__
#define __PUJ_ML__Model__Logistic__h__

#include <PUJ_ML/Model/Linear.h>

namespace PUJ_ML
{
  namespace Model
  {
    /**
     */
    template< class _TScalar >
    class Logistic
      : public Linear< _TScalar >
    {
      PUJ_ML_ModelTypesMacroTemplate( Logistic, Linear< _TScalar > );

      /**
       */
      class Cost
        : public Superclass::Cost
      {
        PUJ_ML_CostTypesMacroTemplate;

      public:
        Cost( Self* model, const TMatrix& X, const TMatrix& Y );
        virtual ~Cost( ) = default;

        virtual TScalar evaluate( TRow* g = nullptr ) override;
      };

    public:
      Logistic( );
      Logistic( const Self& other );
      Self& operator=( const Self& other );
      virtual ~Logistic( ) = default;

    protected:
      virtual void _evaluate( TMatrix& y, const TMatrix& x ) const override;
      virtual void _threshold( TMatrix& y, const TMatrix& x ) const override;
    };
  } // end namespace
} // end namespace

#endif // __PUJ_ML__Model__Logistic__h__

// eof - $RCSfile$
