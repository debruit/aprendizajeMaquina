## =========================================================================
## @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
## =========================================================================

from ..BaseModel import *
import io
import PUJ_ML.Model.NeuralNetwork.Activation

'''
'''
class FeedForward( BaseModel ):

  '''
  Weight matrices are kept in tranposed form.
  '''
  m_W = []
  m_B = []
  m_S = []
  m_InputSize = 0

  '''
  Initialize an object witha zero-sized parameters vector
  '''
  def __init__( self, input_size = 1 ):
    assert isinstance( input_size, ( int ) ) and input_size > 0, \
           'Invalid input size'
    self.m_InputSize = input_size
  # end if

  '''
  addLayer( "ReLU"|func, size = n )
  addLayer( "ReLU"|func, size = n, init = "zero"|"random"|float )
  '''
  def addLayer( self, a, **kwargs ):

    # Input values
    o_size = int( kwargs[ 'size' ] )
    init = 'random'
    if 'init' in kwargs:
      init = kwargs[ 'init' ]
    # end if

    # Weights
    i_size = self.m_InputSize
    if len( self.m_W ) > 0:
      i_size = self.m_W[ -1 ].shape[ 0 ]
    # end if
    if init == 'zero':
      self.m_W += [ numpy.zeros( ( o_size, i_size ) ) ]
    elif init == 'random':
      self.m_W += [ numpy.random.uniform( 1e-2, 1, ( o_size, i_size ) ) ]
    # end if

    # Biases
    if init == 'zero':
      self.m_B += [ numpy.zeros( ( o_size, 1 ) ) ]
    elif init == 'random':
      self.m_B += [ numpy.random.uniform( 1e-2, 1, ( o_size, 1 ) ) ]
    # end if

    # Activation function
    if isinstance( a, ( str ) ):
      self.m_S += [ getattr( PUJ_ML.Model.NeuralNetwork.Activation, a )( ) ]
    else:
      self.m_S += [ a ]
    # end if
  # end def

  '''
  '''
  def numberOfLayers( self ):
    return len( self.m_W )
  # end def

  '''
  '''
  def layerInputSize( self, i ):
    return 0
  # end def

  '''
  '''
  def layerOutputSize( self, i ):
    return 0
  # end def

  '''
  '''
  def layerWeights( self, i ):
    if i < len( self.m_W ):
      return self.m_W[ i ]
    else:
      return None
    # end if
  # end def

  '''
  '''
  def layerBiases( self, i ):
    if i < len( self.m_B ):
      return self.m_B[ i ]
    else:
      return None
    # end if
  # end def

  '''
  '''
  def layerActivation( self, i ):
    if i < len( self.m_S ):
      return self.m_S[ i ]
    else:
      return None
    # end if
  # end def

  '''
  '''
  def numberOfParameters( self ):
    n = 0
    for i in range( len( self.m_W ) ):
      n += ( self.m_W[ i ].shape[ 1 ] + 1 ) * self.m_W[ i ].shape[ 0 ]
    # end for
    return n
  # end def

  def parameters( self ):
    p = None
    L = len( self.m_W )
    if L > 0:
      t = []
      for i in range( L ):
        t += [ self.m_W[ i ].flatten( ) ]
        t += [ self.m_B[ i ].flatten( ) ]
      # end for
      p = numpy.concatenate( tuple( t ) )
    # end if
    return p
  # end def

  def setParameters( self, p ):
    pass
  # end def

  '''
  Final-user methods.
  '''
  def evaluate( self, x ):

    # Validate input
    L = len( self.m_W )
    if L == 0:
      raise ValueError( 'Parameters should be defined first!' )
    # end if

    rx = None
    if not isinstance( x, numpy.matrix ):
      rx = numpy.matrix( x )
    else:
      rx = x
    # end if

    if rx.shape[ 1 ] != self.m_InputSize:
      raise ValueError(
        'Input size (=' + str( rx.shape[ 1 ] ) +
        ') differs from parameters (=' + str( self.m_InputSize )
        + ')'
        )
    # end if

    # Ok, now compute the real deal
    z = self.m_S[ 0 ]( ( self.m_W[ 0 ] @ rx.T ) + self.m_B[ 0 ] )
    for i in range( 1, L ):
      z = self.m_S[ i ]( ( self.m_W[ i ] @ z ) + self.m_B[ i ] )
    # end for
    return z.T
  # end def

  '''
  Streaming methods.
  '''
  def __str__( self ):
    L = len( self.m_W )
    buf = str( L ) + '\n'
    for i in range( L ):
      buf += str( self.m_W[ i ].shape[ 0 ] ) + ' '
      buf += str( self.m_W[ i ].shape[ 1 ] ) + ' '
      buf += str( self.m_S[ i ] ) + '\n'
    # end for
    p = self.parameters( )
    if not p is None:
      b = io.BytesIO( )
      numpy.savetxt( b, p, fmt = '%.4e', newline = ' ', encoding = 'latin1' )
      buf += b.getvalue( ).decode( 'latin1' )[ 0 : -1 ]
    else:
      buf += 'random'
    # end if
    return buf
  # end def

  ## -----------------------------------------------------------------------
  class Cost( BaseModel.Cost ):

    '''
    Initialize an object witha zero-sized parameters vector
    '''
    def __init__( self, model, X, Y ):
      super( ).__init__( model, X, Y )
    # end def

    '''
    Evaluate cost with gradient (if needed)
    '''
    def _evaluate( self, samples, need_gradient = False ):
      X = samples[ 0 ]
      Y = samples[ 1 ]

      # 1. Forward
      A = [ X.T ]
      Z = []
      L = self.m_Model.numberOfLayers( )
      for i in range( L ):
        Z += [ ( self.m_Model.m_W[ i ] @ A[ -1 ] ) + self.m_Model.m_B[ i ] ]
        A += [ self.m_Model.m_S[ i ]( Z[ -1 ] ) ]
      # end if

      # 2. Cost
      J = float( 0 )
      last_activation = str( self.m_Model.m_S[ -1 ] )
      if last_activation == 'SoftMax':
        pass
      elif last_activation == 'Sigmoid':
        a = A[ -1 ].T
        J  = numpy.log( a[ Y == 1 ] + 1e-12 ).sum( )
        J += numpy.log( 1 - a[ Y == 0 ] + 1e-12 ).sum( )
        J /= -float( X.shape[ 0 ] )
      else:
        pass
      # end if

      # 3. Backpropagation
      g = None
      if need_gradient:

        # 3.0 Some values
        m = float( X.shape[ 0 ] )

        # 3.1 Compute deltas
        D = []
        if last_activation == 'SoftMax' or last_activation == 'Sigmoid':
          D += [ ( A[ -1 ] - Y.T ) / m ]
        else:
          pass
        # end if
        for l in range( L - 2, -1, -1 ):
          D += [
            numpy.multiply(
              self.m_Model.m_W[ l + 1 ].T @ D[ -1 ],
              self.m_Model.m_S[ l ]( Z[ l ], True )
              )
            ]
        # end for

        # 3.2 Compute derivatives
        t = []
        for l in range( L ):
          t += [ ( D[ L - 1 - l ] @ A[ l ].T ).flatten( ) ]
          t += [ D[ L - 1 - l ].mean( axis = 1 ).flatten( ) ]
        # end for
        g = numpy.concatenate( tuple( t ) ).\
            reshape( ( self.m_Model.numberOfParameters( ), 1 ) )
      # end if

      # Finish
      return [ J, g ]
    # end def

    '''
    Move parameters along a direction
    '''
    def move( self, d ):
      o = 0
      L = len( self.m_Model.m_W )
      for l in range( L ):
        b = self.m_Model.m_W[ l ].shape[ 0 ]
        w = self.m_Model.m_W[ l ].shape[ 1 ] * b
        self.m_Model.m_W[ l ] += \
          d[ o : o + w ].reshape( self.m_Model.m_W[ l ].shape )
        self.m_Model.m_B[ l ] += \
          d[ o + w : o + w + b ].reshape( self.m_Model.m_B[ l ].shape )
      # end for
    # end def

  # end class
# end class

## eof - $RCSfile$
