// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================
#ifndef __PUJ_ML__Optimizer__GradientDescent__h__
#define __PUJ_ML__Optimizer__GradientDescent__h__

#include <PUJ_ML/Optimizer/Base.h>

namespace PUJ_ML
{
  namespace Optimizer
  {
    /**
     */
    template< class _TScalar >
    class GradientDescent
      : public Base< _TScalar >
    {
    public:
      using Self       = GradientDescent;
      using Superclass = Base< _TScalar >;

      using TScalar  = typename Superclass::TScalar;
      using TNatural = typename Superclass::TNatural;
      using TCost    = typename Superclass::TCost;
      using TMatrix  = typename Superclass::TMatrix;
      using TColumn  = typename Superclass::TColumn;
      using TRow     = typename Superclass::TRow;

    public:
      GradientDescent( TCost* cost );
      virtual ~GradientDescent( ) = default;

      TScalar learningRate( ) const;
      TScalar epsilon( ) const;

      void setLearningRate( const TScalar& a );
      void setEpsilon( const TScalar& e );

      virtual void Fit( ) override;

    protected:
      TScalar m_Alpha   { 1e-1 };
      TScalar m_Epsilon { std::numeric_limits< TScalar >::epsilon( ) };
    };
  } // end namespace
} // end namespace

#endif // __PUJ_ML__Optimizer__GradientDescent__h__

// eof - $RCSfile$
