// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================
#ifndef __PUJ_ML__Model__Base__h__
#define __PUJ_ML__Model__Base__h__



#include <iostream>








#include <Eigen/Core>
#include <vector>

// -------------------------------------------------------------------------
#define PUJ_ML_ModelTypesMacroTemplate( _b, _s )              \
  public:                                                     \
  using Self       = _b;                                      \
  using Superclass = _s;                                      \
  using TScalar    = typename Superclass::TScalar;            \
  using TNatural   = typename Superclass::TNatural;           \
  using TMatrix    = typename Superclass::TMatrix;            \
  using TColumn    = typename Superclass::TColumn;            \
  using TRow       = typename Superclass::TRow;               \
  using TMatrixMap = typename Superclass::TMatrixMap;         \
  using TColumnMap = typename Superclass::TColumnMap;         \
  using TRowMap    = typename Superclass::TRowMap

// -------------------------------------------------------------------------
#define PUJ_ML_ModelTypesMacro( _b, _s )     \
  public:                                    \
  using Self       = _b;                     \
  using Superclass = _s;                     \
  using TScalar    = Superclass::TScalar;    \
  using TNatural   = Superclass::TNatural;   \
  using TMatrix    = Superclass::TMatrix;    \
  using TColumn    = Superclass::TColumn;    \
  using TRow       = Superclass::TRow;       \
  using TMatrixMap = Superclass::TMatrixMap; \
  using TColumnMap = Superclass::TColumnMap; \
  using TRowMap    = Superclass::TRowMap

// -------------------------------------------------------------------------
#define PUJ_ML_CostTypesMacroTemplate                   \
  public:                                               \
  using TScalar    = typename Self::TScalar;            \
  using TNatural   = typename Self::TNatural;           \
  using TMatrix    = typename Self::TMatrix;            \
  using TColumn    = typename Self::TColumn;            \
  using TRow       = typename Self::TRow;               \
  using TMatrixMap = typename Self::TMatrixMap;         \
  using TColumnMap = typename Self::TColumnMap;         \
  using TRowMap    = typename Self::TRowMap

// -------------------------------------------------------------------------
#define PUJ_ML_CostTypesMacro          \
  public:                              \
  using TScalar    = Self::TScalar;    \
  using TNatural   = Self::TNatural;   \
  using TMatrix    = Self::TMatrix;    \
  using TColumn    = Self::TColumn;    \
  using TRow       = Self::TRow;       \
  using TMatrixMap = Self::TMatrixMap; \
  using TColumnMap = Self::TColumnMap; \
  using TRowMap    = Self::TRowMap

namespace PUJ_ML
{
  namespace Model
  {
    /**
     */
    template< class _TScalar >
    class Base
    {
    public:
      using Self     = Base;
      using TScalar  = _TScalar;
      using TNatural = unsigned long long;

      using TMatrix = Eigen::Matrix< TScalar, Eigen::Dynamic, Eigen::Dynamic >;
      using TColumn = Eigen::Matrix< TScalar, Eigen::Dynamic, 1 >;
      using TRow    = Eigen::Matrix< TScalar, 1, Eigen::Dynamic >;
      using TMatrixMap = Eigen::Map< TMatrix >;
      using TColumnMap = Eigen::Map< TColumn >;
      using TRowMap    = Eigen::Map< TRow >;

      /**
       */
      class Cost
      {
        PUJ_ML_CostTypesMacroTemplate;

      public:
        Cost( Self* model, const TMatrix& X, const TMatrix& Y );
        virtual ~Cost( ) = default;;

        Self* model( );
        const Self* model( ) const;

        void move( const TRow& d );

        virtual TScalar evaluate( TRow* g = nullptr ) = 0;

      protected:
        /*
         * Model associated to this cost
         * @type Something derived from PUJ.Model.Base
         */
        Self* m_Model { nullptr };
        const TMatrix* m_X  { nullptr };
        const TMatrix* m_Y  { nullptr };
      };

    public:
      Base( );
      Base( const Self& r );
      Self& operator=( const Self& r );
      virtual ~Base( );

      void clear( );
      TNatural inputSize( ) const;
      virtual TNatural outputSize( ) const = 0;
      TNatural numberOfParameters( ) const;
      TScalar* parameters( );
      const TScalar* parameters( ) const;

      template< class _T >
      void setParameters( std::initializer_list< _T > c );

      template< class _T >
      void setParameters( const Eigen::Matrix< _T, 1, Eigen::Dynamic >& r );

      template< class _T >
      void setParameters( const Eigen::Matrix< _T, Eigen::Dynamic, 1 >& c );

      template< class _T >
      void setParameters(
        const Eigen::Matrix< _T, Eigen::Dynamic, Eigen::Dynamic >& m
        );

      template< class _TContainer >
      void setParameters( const _TContainer& c );

      template< class _T >
      TMatrix evaluate( std::initializer_list< _T > x ) const;

      template< class _T >
      TMatrix evaluate(
        const Eigen::Matrix< _T, 1, Eigen::Dynamic >& r
        ) const;

      template< class _T >
      TMatrix evaluate(
        const Eigen::Matrix< _T, Eigen::Dynamic, Eigen::Dynamic >& X
        ) const;

      template< class _TContainer >
      TMatrix evaluate( const _TContainer& c ) const;

      template< class _T >
      TMatrix threshold( std::initializer_list< _T > x ) const;

      template< class _T >
      TMatrix threshold(
        const Eigen::Matrix< _T, 1, Eigen::Dynamic >& r
        ) const;

      template< class _T >
      TMatrix threshold(
        const Eigen::Matrix< _T, Eigen::Dynamic, Eigen::Dynamic >& m
        ) const;

      template< class _TContainer >
      TMatrix threshold( const _TContainer& c ) const;

      template< class _S >
      Self& operator<<( const _S& n );

    protected:
      virtual void _evaluate( TMatrix& y, const TMatrix& x ) const = 0;
      virtual void _threshold( TMatrix& y, const TMatrix& x ) const;

      void _connectBuffer( );
      void _fromStream( std::istream& i );
      void _toStream( std::ostream& o ) const;

    protected:
      /*
       * Paramateres for this model. This allows the programmer to control
       * memory usage.
       */
      std::vector< TScalar > m_Buffer;
      TColumnMap* m_Column { nullptr };
      TRowMap*    m_Row    { nullptr };

    public:
      struct _NotReallyUsed
      {
        operator TScalar( ) const { return( TScalar( 0 ) ); }
      };
      static const _NotReallyUsed end;

    public:
      friend std::istream& operator>>( std::istream& i, Self& m )
        {
          m._fromStream( i );
          return( i );
        }
      friend std::ostream& operator<<( std::ostream& o, const Self& m )
        {
          m._toStream( o );
          return( o );
        }
    };
  } // end namespace
} // end namespace

#include <PUJ_ML/Model/Base.hxx>

#endif // __PUJ_ML__Model__Base__h__

// eof - $RCSfile$
