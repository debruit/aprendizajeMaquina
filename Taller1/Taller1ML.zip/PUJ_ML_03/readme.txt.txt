1. El archivo que contiene la interfaz de usuario es PUJ_ML_03\examples\python3\playgroundExample.py
para ejecutarlo se necesita el archivo .npz PUJ_ML_03\examples\data\clasificadores.npz
donde se encuentran los modelos cargados.
2. El archivo que contiene el entrenamiento de los clasificadores logisticos independientes es 
PUJ_ML_03\examples\python3\entrenamientoClasificadores.py

