## =========================================================================
## @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
## =========================================================================

def Simple( model, i, J, dJ, show ):
  if show:
    print( i, J, dJ )
  # end if
# end def

## eof - $RCSfile$
