// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================

#include <PUJ_ML/Export.h>
#include <PUJ_ML/Model/Base.h>

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Model::Base< _TScalar >::Cost::
Cost( Self* model, const TMatrix& X, const TMatrix& Y )
  : m_Model( model ),
    m_X( &X ),
    m_Y( &Y )
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Model::Base< _TScalar >::
Self* PUJ_ML::Model::Base< _TScalar >::Cost::
model( )
{
  return( this->m_Model );
}

// -------------------------------------------------------------------------
template< class _TScalar >
const typename PUJ_ML::Model::Base< _TScalar >::
Self* PUJ_ML::Model::Base< _TScalar >::Cost::
model( ) const
{
  return( this->m_Model );
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Model::Base< _TScalar >::Cost::
move( const TRow& d )
{
  /* TODO
     Eigen::Map< TRow > p(
     this->m_Model->parameters( ), this->m_Model->numberOfParameters( )
     );
     p += d;
  */
}

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Model::Base< _TScalar >::
Base( )
{
}

// -------------------------------------------------------------------------
/* TODO
   template< class _TScalar >
   PUJ_ML::Model::Base< _TScalar >::
   Base( const std::vector< TScalar >& p )
   {
   this->m_Buffer.insert( this->m_Buffer.begin( ), p.begin( ), p.end( ) );
   this->m_Buffer.shrink_to_fit( );
   this->_connectBuffer( );
   }
*/

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Model::Base< _TScalar >::
Base( const Self& r )
{
  this->m_Buffer.insert(
    this->m_Buffer.begin( ), r.m_Buffer.begin( ), r.m_Buffer.end( )
    );
  this->_connectBuffer( );
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Model::Base< _TScalar >::
Self& PUJ_ML::Model::Base< _TScalar >::
operator=( const Self& r )
{
  this->m_Buffer.clear( );
  this->m_Buffer.insert(
    this->m_Buffer.begin( ), r.m_Buffer.begin( ), r.m_Buffer.end( )
    );
  this->_connectBuffer( );
  return( *this );
}

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Model::Base< _TScalar >::
~Base( )
{
  if( this->m_Column != nullptr )
    delete this->m_Column;
  if( this->m_Row != nullptr )
    delete this->m_Row;
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Model::Base< _TScalar >::
clear( )
{
  this->m_Buffer.clear( );
  if( this->m_Column != nullptr )
    delete this->m_Column;
  if( this->m_Row != nullptr )
    delete this->m_Row;
  this->m_Column = nullptr;
  this->m_Row = nullptr;
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Model::Base< _TScalar >::
TNatural PUJ_ML::Model::Base< _TScalar >::
inputSize( ) const
{
  return( this->m_Buffer.size( ) - 1 );
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Model::Base< _TScalar >::
TNatural PUJ_ML::Model::Base< _TScalar >::
numberOfParameters( ) const
{
  return( this->m_Buffer.size( ) );
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Model::Base< _TScalar >::
TScalar* PUJ_ML::Model::Base< _TScalar >::
parameters( )
{
  return( this->m_Buffer.data( ) );
}

// -------------------------------------------------------------------------
template< class _TScalar >
const typename PUJ_ML::Model::Base< _TScalar >::
TScalar* PUJ_ML::Model::Base< _TScalar >::
parameters( ) const
{
  return( this->m_Buffer.data( ) );
}

// -------------------------------------------------------------------------
/* TODO
   template< class _TScalar >
   void PUJ_ML::Model::Base< _TScalar >::
   setParameters( const std::vector< TScalar >& p )
   {
   this->m_Buffer.clear( );
   this->m_Buffer.insert( this->m_Buffer.begin( ), p.begin( ), p.end( ) );
   this->m_Buffer.shrink_to_fit( );
   this->_connectBuffer( );
   }

*/

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Model::Base< _TScalar >::
_threshold( TMatrix& y, const TMatrix& x ) const
{
  this->_evaluate( y, x );
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Model::Base< _TScalar >::
_connectBuffer( )
{
  if( this->m_Column != nullptr )
    delete this->m_Column;
  if( this->m_Row != nullptr )
    delete this->m_Row;

  this->m_Buffer.shrink_to_fit( );

  this->m_Column = new TColumnMap(
    const_cast< TScalar* >( this->m_Buffer.data( ) ) + 1,
    this->m_Buffer.size( ) - 1
    );

  this->m_Row = new TRowMap(
    const_cast< TScalar* >( this->m_Buffer.data( ) ) + 1,
    this->m_Buffer.size( ) - 1
    );
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Model::Base< _TScalar >::
_fromStream( std::istream& i )
{
  TScalar v;
  TNatural N;
  i >> N;
  this->m_Buffer.clear( );
  for( TNatural n = 0; n < N; ++n )
  {
    i >> v;
    this->m_Buffer.push_back( v );
  } // end for
  this->_connectBuffer( );
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Model::Base< _TScalar >::
_toStream( std::ostream& o ) const
{
  o << this->m_Buffer.size( );
  for( auto v: this->m_Buffer )
    o << " " << v;
}

// -------------------------------------------------------------------------
template class PUJ_ML_EXPORT PUJ_ML::Model::Base< float >;
template class PUJ_ML_EXPORT PUJ_ML::Model::Base< double >;
template class PUJ_ML_EXPORT PUJ_ML::Model::Base< long double >;

// eof - $RCSfile$
