## =========================================================================
## @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
## =========================================================================

from .GradientDescent import *
from .Debug import *

## eof - $RCSfile$
