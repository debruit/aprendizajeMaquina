// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================
#ifndef __PUJ_ML__Model__Base__hxx__
#define __PUJ_ML__Model__Base__hxx__
 
// -------------------------------------------------------------------------
template< class _TScalar >
template< class _T >
void PUJ_ML::Model::Base< _TScalar >::
setParameters( std::initializer_list< _T > c )
{
  this->m_Buffer.clear( );
  for( const _T& v: c )
    this->m_Buffer.push_back( TScalar( v ) );
  this->_connectBuffer( );
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _T >
void PUJ_ML::Model::Base< _TScalar >::
setParameters( const Eigen::Matrix< _T, 1, Eigen::Dynamic >& r )
{
  this->clear( );
  for( TNatural i = 0; i < r.cols( ); ++i )
    this->m_Buffer.push_back( TScalar( r( i ) ) );
  this->_connectBuffer( );
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _T >
void PUJ_ML::Model::Base< _TScalar >::
setParameters( const Eigen::Matrix< _T, Eigen::Dynamic, 1 >& c )
{
  this->clear( );
  for( TNatural i = 0; i < c.rows( ); ++i )
    this->m_Buffer.push_back( TScalar( c( i ) ) );
  this->_connectBuffer( );
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _T >
void PUJ_ML::Model::Base< _TScalar >::
setParameters( const Eigen::Matrix< _T, Eigen::Dynamic, Eigen::Dynamic >& m )
{
  this->clear( );
  for( TNatural r = 0; r < m.rows( ); ++r )
    for( TNatural c = 0; c < m.cols( ); ++c )
      this->m_Buffer.push_back( TScalar( m( r, c ) ) );
  this->_connectBuffer( );
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _TContainer >
void PUJ_ML::Model::Base< _TScalar >::
setParameters( const _TContainer& c )
{
  this->clear( );
  for( const auto& v: c )
    this->m_Buffer.push_back( TScalar( v ) );
  this->_connectBuffer( );
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _T >
typename PUJ_ML::Model::Base< _TScalar >::
TMatrix PUJ_ML::Model::Base< _TScalar >::
evaluate( std::initializer_list< _T > x ) const
{
  if( x.size( ) % this->inputSize( ) == 0 )
  {
    TMatrix X( x.size( ) / this->inputSize( ), x.size( ) );
    TNatural i = 0;
    for( TNatural r = 0; r < X.rows( ); ++r )
      for( TNatural c = 0; c < X.cols( ); ++c )
        X( r, c ) = TScalar( x[ i++ ] );
    TMatrix Y( X.rows( ), this->outputSize( ) );
    this->_evaluate( Y, X );
    return( Y );
  }
  else
    return( TMatrix::Zero( 1 ) );
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _T >
typename PUJ_ML::Model::Base< _TScalar >::
TMatrix PUJ_ML::Model::Base< _TScalar >::
evaluate( const Eigen::Matrix< _T, 1, Eigen::Dynamic >& r ) const
{
  if( r.cols( ) == this->inputSize( ) )
  {
    TMatrix X = r.template cast< TScalar >( );
    TMatrix Y( X.rows( ), this->outputSize( ) );
    this->_evaluate( Y, X );
    return( Y );
  }
  else
    return( TMatrix::Zero( 1 ) );
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _T >
typename PUJ_ML::Model::Base< _TScalar >::
TMatrix PUJ_ML::Model::Base< _TScalar >::
evaluate( const Eigen::Matrix< _T, Eigen::Dynamic, Eigen::Dynamic >& X ) const
{
  if( X.cols( ) == this->inputSize( ) )
  {
    TMatrix Y( X.rows( ), this->outputSize( ) );
    this->_evaluate( Y, X.template cast< TScalar >( ) );
    return( Y );
  }
  else
    return( TMatrix::Zero( 1 ) );
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _TContainer >
typename PUJ_ML::Model::Base< _TScalar >::
TMatrix PUJ_ML::Model::Base< _TScalar >::
evaluate( const _TContainer& c ) const
{
  /* TODO
     if( c.size( ) % this->inputSize( ) == 0 )
     {
     TMatrix X( c.size( ) / this->inputSize( ), c.size( ) );
     TNatural i = 0;
     for( TNatural r = 0; r < X.rows( ); ++r )
     for( TNatural c = 0; c < X.cols( ); ++c )
     X( r, c ) = TScalar( c[ i++ ] );
     TMatrix Y( X.rows( ), this->outputSize( ) );
     this->_evaluate( Y, X );
     return( Y );
     }
     else
     return( TMatrix::Zero( 1 ) );
  */
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _T >
typename PUJ_ML::Model::Base< _TScalar >::
TMatrix PUJ_ML::Model::Base< _TScalar >::
threshold( std::initializer_list< _T > x ) const
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _T >
typename PUJ_ML::Model::Base< _TScalar >::
TMatrix PUJ_ML::Model::Base< _TScalar >::
threshold( const Eigen::Matrix< _T, 1, Eigen::Dynamic >& r ) const
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _T >
typename PUJ_ML::Model::Base< _TScalar >::
TMatrix PUJ_ML::Model::Base< _TScalar >::
threshold( const Eigen::Matrix< _T, Eigen::Dynamic, Eigen::Dynamic >& m ) const
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _TContainer >
typename PUJ_ML::Model::Base< _TScalar >::
TMatrix PUJ_ML::Model::Base< _TScalar >::
threshold( const _TContainer& c ) const
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
template< class _S >
typename PUJ_ML::Model::Base< _TScalar >::
Self& PUJ_ML::Model::Base< _TScalar >::
operator<<( const _S& n )
{
  static bool _init = true;

  if( _init )
    _init = false;

  if( typeid( n ) == typeid( Self::_NotReallyUsed ) )
  {
    _init = true;
    this->_connectBuffer( );
  }
  else
    this->m_Buffer.push_back( TScalar( n ) );

  return( *this );
}

#endif // __PUJ_ML__Model__Base__hxx__

// eof - $RCSfile$
