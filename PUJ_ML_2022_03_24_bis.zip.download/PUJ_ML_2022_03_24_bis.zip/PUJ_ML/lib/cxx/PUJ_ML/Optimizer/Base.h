// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================
#ifndef __PUJ_ML__Optimizer__Base__h__
#define __PUJ_ML__Optimizer__Base__h__

#include <functional>
#include <PUJ_ML/Model/Base.h>

namespace PUJ_ML
{
  namespace Optimizer
  {
    /**
     */
    template< class _TScalar >
    class Base
    {
    public:
      using Self = Base;

      using TScalar  = _TScalar;
      using TCost    = typename PUJ_ML::Model::Base< TScalar >::Cost;
      using TNatural = typename TCost::TNatural;
      using TMatrix  = typename TCost::TMatrix;
      using TColumn  = typename TCost::TColumn;
      using TRow     = typename TCost::TRow;

      using TDebug =
        std::function< bool( TCost*, TNatural, TScalar, TScalar, bool ) >;

    public:
      Base( TCost* cost );
      virtual ~Base( ) = default;

      TNatural maximumNumberOfIterations( ) const;
      TNatural numberOfDebugIterations( ) const;
      TNatural iteration( ) const;

      void setMaximumNumberOfIterations( const TNatural& i );
      void setNumberOfDebugIterations( const TNatural& i );

      virtual void Fit( ) = 0;

    protected:
      TNatural m_MaximumNumberOfIterations { 10000 };
      TNatural m_NumberOfDebugIterations   { 10 };
      TNatural m_Iteration;
      TDebug   m_Debug;

      TCost* m_Cost { nullptr };
    };
  } // end namespace
} // end namespace

#endif // __PUJ_ML__Optimizer__Base__h__

// eof - $RCSfile$
