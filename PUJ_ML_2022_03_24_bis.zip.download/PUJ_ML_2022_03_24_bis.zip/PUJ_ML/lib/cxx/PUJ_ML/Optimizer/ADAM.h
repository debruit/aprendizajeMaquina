// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================
#ifndef __PUJ_ML__Optimizer__ADAM__h__
#define __PUJ_ML__Optimizer__ADAM__h__

#include <PUJ_ML/Optimizer/GradientDescent.h>

namespace PUJ_ML
{
  namespace Optimizer
  {
    /**
     */
    template< class _TScalar >
    class ADAM
      : public GradientDescent< _TScalar >
    {
    public:
      using Self       = ADAM;
      using Superclass = GradientDescent< _TScalar >;

      using TScalar  = typename Superclass::TScalar;
      using TNatural = typename Superclass::TNatural;
      using TCost    = typename Superclass::TCost;
      using TMatrix  = typename Superclass::TMatrix;
      using TColumn  = typename Superclass::TColumn;
      using TRow     = typename Superclass::TRow;

    public:
      ADAM( TCost* cost );
      virtual ~ADAM( ) = default;

      TScalar firstDamping( ) const;
      TScalar secondDamping( ) const;

      void setFirstDamping( const TScalar& b );
      void setSecondDamping( const TScalar& b );

      virtual void Fit( ) override;

    protected:
      TScalar m_Beta1 { 0.9 };
      TScalar m_Beta2 { 0.999 };
    };
  } // end namespace
} // end namespace

#endif // __PUJ_ML__Optimizer__ADAM__h__

// eof - $RCSfile$
