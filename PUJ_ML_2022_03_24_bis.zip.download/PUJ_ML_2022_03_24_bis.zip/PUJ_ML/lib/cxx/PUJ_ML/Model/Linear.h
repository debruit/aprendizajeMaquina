// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================
#ifndef __PUJ_ML__Model__Linear__h__
#define __PUJ_ML__Model__Linear__h__

#include <PUJ_ML/Model/Base.h>

namespace PUJ_ML
{
  namespace Model
  {
    /**
     */
    template< class _TScalar >
    class Linear
      : public Base< _TScalar >
    {
      PUJ_ML_ModelTypesMacroTemplate( Linear, Base< _TScalar > );

      /**
       */
      class Cost
        : public Superclass::Cost
      {
        PUJ_ML_CostTypesMacroTemplate;

      public:
        Cost( Self* model, const TMatrix& X, const TMatrix& Y );
        virtual ~Cost( ) = default;

        virtual TScalar evaluate( TRow* g = nullptr ) override;

      protected:
        TMatrix m_XtX;
        TRow    m_mX;
        TRow    m_mXY;
        TScalar m_mY;
        TScalar m_YtY;
      };

    public:
      Linear( );
      Linear( const Self& other );
      Self& operator=( const Self& other );
      virtual ~Linear( ) = default;

      virtual TNatural outputSize( ) const override;

    protected:
      virtual void _evaluate( TMatrix& y, const TMatrix& x ) const override;
    };
  } // end namespace
} // end namespace

#endif // __PUJ_ML__Model__Linear__h__

// eof - $RCSfile$
