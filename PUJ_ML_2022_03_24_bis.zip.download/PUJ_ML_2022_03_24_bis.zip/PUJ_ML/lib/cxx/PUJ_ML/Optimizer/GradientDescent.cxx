// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================

#include <PUJ_ML/Export.h>
#include <PUJ_ML/Optimizer/GradientDescent.h>

// -------------------------------------------------------------------------
template< class _TScalar >
PUJ_ML::Optimizer::GradientDescent< _TScalar >::
GradientDescent( TCost* cost )
  : Superclass( cost )
{
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Optimizer::GradientDescent< _TScalar >::
TScalar PUJ_ML::Optimizer::GradientDescent< _TScalar >::
learningRate( ) const
{
  return( this->m_Alpha );
}

// -------------------------------------------------------------------------
template< class _TScalar >
typename PUJ_ML::Optimizer::GradientDescent< _TScalar >::
TScalar PUJ_ML::Optimizer::GradientDescent< _TScalar >::
epsilon( ) const
{
  return( this->m_Epsilon );
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Optimizer::GradientDescent< _TScalar >::
setLearningRate( const TScalar& a )
{
  this->m_Alpha = a;
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Optimizer::GradientDescent< _TScalar >::
setEpsilon( const TScalar& e )
{
  this->m_Epsilon = e;
}

// -------------------------------------------------------------------------
template< class _TScalar >
void PUJ_ML::Optimizer::GradientDescent< _TScalar >::
Fit( )
{
  // Initial values
  TRow g;
  TScalar a = this->m_Alpha * TScalar( -1 );
  TScalar J0 = this->m_Cost->evaluate( &g ), J1;

  // Prepare loop
  bool stop = false;
  this->m_Iteration = 0;

  // Main loop
  while( !stop )
  {
    // Advance
    this->m_Cost->move( g * a );
    J1 = this->m_Cost->evaluate( &g );
    stop = this->m_Debug(
      this->m_Cost, this->m_Iteration, J0, J0 - J1,
      this->m_Iteration % this->m_NumberOfDebugIterations == 0
      );

    // Update iterations
    this->m_Iteration++;
    stop |= this->m_Iteration >= this->m_MaximumNumberOfIterations;
    stop |= ( ( J0 - J1 ) < this->m_Epsilon );
    J0 = J1;
  } // end while

  // Final debug call
  this->m_Debug( this->m_Cost, this->m_Iteration, J0, J0 - J1, true );
}

// -------------------------------------------------------------------------
template class PUJ_ML_EXPORT PUJ_ML::Optimizer::GradientDescent< float >;
template class PUJ_ML_EXPORT PUJ_ML::Optimizer::GradientDescent< double >;
template class PUJ_ML_EXPORT PUJ_ML::Optimizer::GradientDescent< long double >;

// eof - $RCSfile$
